#!/bin/bash

./stop.sh
./start.sh